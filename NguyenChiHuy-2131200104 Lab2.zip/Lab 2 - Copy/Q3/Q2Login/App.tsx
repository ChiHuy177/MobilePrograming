import React from "react";
import LoginScreen from './Login/login'

function App(){
  return(
    <LoginScreen/>
  )
};
export default App;